import React, { useState } from "react";
import { Link } from "react-router-dom";
import { IoClose, IoMenu } from "react-icons/io5";
import "./Menu.css";

const Menu = () => {
  const [showMenu, setShowMenu] = useState(false);
  const [activeSubmenu, setActiveSubmenu] = useState(null);

  const toggleMenu = () => {
    setShowMenu(!showMenu);
  };

  const closeMenuOnMobile = () => {
    setShowMenu(false);
    setActiveSubmenu(null);
  };

  const toggleSubmenu = (index) => {
    setActiveSubmenu(activeSubmenu === index ? null : index);
  };

  return (
    <header className="header">
      <nav className="nav container">
        <div className={`nav__menu ${showMenu ? "show-menu" : ""}`} id="nav-menu">
          <ul className="nav__list">
            <li className="nav__item">
              <Link to="/" className="nav__link" onClick={closeMenuOnMobile}>
                Домашняя страница
              </Link>
            </li>
            <li className="nav__item">
              <div className="nav__link" onClick={() => toggleSubmenu(1)}>
                Типовые динамические звенья
              </div>
              <ul className={`nav__submenu ${activeSubmenu === 1 ? "show-submenu" : ""}`}>
                <li className="nav__subitem">
                  <Link to="/Positional_links" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Позиционные Звенья
                  </Link>
                </li>
                <li className="nav__subitem">
                  <Link to="/Integrating_links" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Интегрирующие звенья
                  </Link>
                </li>
                <li className="nav__subitem">
                  <Link to="/Differentiating_links" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Дифференцирующие звенья
                  </Link>
                </li>
                <li className="nav__subitem">
                  <Link to="/Links_Modeling" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Моделирование
                  </Link>
                </li>
              </ul>
            </li>
            <li className="nav__item">
              <div className="nav__link" onClick={() => toggleSubmenu(2)}>
                Обратная связь
              </div>
              <ul className={`nav__submenu ${activeSubmenu === 2 ? "show-submenu" : ""}`}>
                <li className="nav__subitem">
                  <Link to="/Feedback" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Основные Понятия
                  </Link>
                </li>
                <li className="nav__subitem">
                  <Link to="/Feedback_Modeling" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Моделирование
                  </Link>
                </li>
              </ul>
            </li>
            <li className="nav__item">
              <div className="nav__link" onClick={() => toggleSubmenu(3)}>
                Устойчивость
              </div>
              <ul className={`nav__submenu ${activeSubmenu === 3 ? "show-submenu" : ""}`}>
                <li className="nav__subitem">
                  <Link to="/Stability_Research_Methods" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Методы Исследования устойчивости САУ и Корневой критерий устойчивости
                  </Link>
                </li>
                <li className="nav__subitem">
                  <Link to="/Routh_Hurwitz" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Метод Рауса и метод Гурвица
                  </Link>
                </li>
                <li className="nav__subitem">
                  <Link to="/Mikhailov_and_Nyquist" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Метод Михайлова и метод Найквиста
                  </Link>
                </li>
              </ul>
            </li>
            <li className="nav__item">
              <div className="nav__link" onClick={() => toggleSubmenu(2)}>
                Показатели качество САУ
              </div>
              <ul className={`nav__submenu ${activeSubmenu === 2 ? "show-submenu" : ""}`}>
                <li className="nav__subitem">
                  <Link to="/Assessing_quality_of_regulation" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Оценка качества регулирования
                  </Link>
                </li>
                <li className="nav__subitem">
                  <Link to="/Direct_integral" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Прямые и Интегральные оценки качества
                  </Link>
                </li>
              </ul>
            </li>
            <li className="nav__item">
              <div className="nav__link" onClick={() => toggleSubmenu(2)}>
                Исследование САУ с запаздыванием
              </div>
              <ul className={`nav__submenu ${activeSubmenu === 2 ? "show-submenu" : ""}`}>
                <li className="nav__subitem">
                  <Link to="/Mathematical_description_and_modeling_of_delay" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Описание САУ с запаздыванием
                  </Link>
                </li>
                <li className="nav__subitem">
                  <Link to="/Stability_study" className="nav__sublink" onClick={closeMenuOnMobile}>
                    Исследование на устойчивость
                  </Link>
                </li>
              </ul>
            </li>
            <li className="nav__item">
              <Link to="/calc" className="nav__link" onClick={closeMenuOnMobile}>
                Калькулятор
              </Link>
            </li>
            <li className="nav__item">
              <Link to="/about" className="nav__link" onClick={closeMenuOnMobile}>
                О создателях
              </Link>
            </li>
          </ul>
          <div className="nav__close" id="nav-close" onClick={toggleMenu}>
            <IoClose />
          </div>
        </div>

        <div className="nav__toggle" id="nav-toggle" onClick={toggleMenu}>
          <IoMenu />
        </div>
      </nav>
    </header>
  );
};

export default Menu;