import React from 'react';
import MathJaxComponent from '../MathJaxComponent.jsx';
import '../ContentPage.css';

import logo from '../Images/logo.png';


const Subject1 = () => {
  const mathExpression1 = '\\[  W(p)=\\frac{k}{T^2p^2+2 \\zeta Tp+1} \\]'

  return (
    <div className="content-container">
      <header>
        <div className='headers'>
            <img src={logo} alt="Logo" className="logo" />
            <div className="header-text">
                <h1>ТЕОРИЯ АВТОМАТИЧЕСКОГО УПРАВЛЕНИЯ</h1>
                <p>САЙТ-ПОМОЩНИК ДЛЯ СТУДЕНТОВ</p>
            </div>
        </div>
      </header>
      <div className="content">
        
      <h2>
      Моделирование
      </h2>

      <h3>
      Моделирование колебательного звена
      </h3>

      <p>
      Передаточная функция колебательного звена<MathJaxComponent mathExpression={mathExpression1} /><br />
      Ей соответствует линейное неоднородное дифференциальное уравнение второго порядка<br />
      {"\\[ T^2\\frac{d^2y}{dt^2}+2 \\zeta T\\frac{dy}{dt}+y=kg  \\]"}<br />
      Избавимся от коэффициента при старшей производной, разделив на него:<br />
      {"\\[ \\frac{d^2y}{dt^2}+\\frac{2\\zeta}{T}\\frac{dy}{dt}+\\frac{y}{T^2}=\\frac{k}{T^2}g  \\]"}<br />
      {"\\[  n=2; \\alpha_2=1; \\alpha_1= \\frac{2\\zeta}{T};\\alpha_0=\\frac{1}{T^2} \\]"}<br />
      {"\\[ m=0;b_2=0;b_1=0;b_0=\\frac{k}{T^2}  \\]"}<br />
      Подготовим звено к моделированию методом непосредственного интегрирования<br />
      {"\\[ y = z_1+b_ng=z_1+b_2g=z_1  \\]"}<br />
      {"\\[ \\frac{dz_1}{dt}=-(\\alpha_{n-1}y-b_{n-1}g)+z_2=-(\\alpha_1y-b_1g)+z_2=-\\frac{2\\zeta}{T}y+z_2  \\]"}<br />
      {"\\[ \\frac{dz_2}{dt}=-(\\alpha_{n-2}y-b_{n-2}g)+z_{n+1}=-(\\alpha_0y-b_0g)+z_3  \\]"}<br />
      так как {"\\[ z_{n+1}=0  \\]"}, получим<br />
      {"\\[ \\frac{dz_2}{dt}=-(\\alpha_0y-b_0g)=-\\frac{y}{T^2} + \\frac{k}{T^2}g  \\]"}<br />
      В результате подготовки исходному дифференциальному уравнению 2-го порядка
      соответствует система из двух дифференциальных уравнений 1-го порядка:<br />
      {"\\[  \\begin{cases}   y=z_1 \\\\ \\frac{dz_1}{dt} = z_2-\\frac{2\\zeta}{T}y \\\\ \\frac{dz_2}{dt}=\\frac{k}{T^2}g -\\frac{y}{T^2} \\end{cases} \\]"}<br />
      Для решения системы дифференциальных уравнений применим метод Рунге-Кутты.<br />
      {"\\[  k_1=dt(z_2-\\frac{2\\zeta}{T}y) \\]"}<br />
      {"\\[ m_1=dt(\\frac{k}{T^2}g-\\frac{y}{T^2})  \\]"}<br />
      {"\\[ k_2=dt(z_2+\\frac{m_1}{2}-\\frac{2\\zeta}{T}(y+\\frac{k_1}{2}))  \\]"}<br />
      {"\\[ m_2=dt(\\frac{k}{T^2}g-\\frac{1}{T^2}(y+\\frac{k_1}{2}))  \\]"}<br />
      {"\\[  k_3=dt(z_2+\\frac{m_2}{2}-\\frac{2\\zeta}{T}(y+\\frac{k_2}{2}))  \\]"}<br />
      {"\\[  m_3=dt(\\frac{k}{T^2}g-\\frac{1}{T^2}(y+\\frac{k_2}{2})) \\]"}<br />
      {"\\[ k_4=dt(z_2+m_3-\\frac{2\\zeta}{T}(y+k_3))  \\]"}<br />
      {"\\[ m_4=dt(\\frac{k}{T^2}g-\\frac{1}{T^2}(y+k_3))  \\]"}<br />
      {"\\[  z_1 = z_1+(k_1+2k_2+2k_3+k_4)\\frac{1}{6} \\]"}<br />
      {"\\[ z_2 = z_2+(m_1+2m_2+2m_3+m_4)\\frac{1}{6}  \\]"}<br />
      Из интернет-источников «подсматривать» формулы лучше  в http://www.codenet.ru/progr/alg/Runge-Kutt-Method/. 
      </p>

      <h3>
      Моделирование инерционного звена первого порядка
      </h3>

      <p>
      Выполним моделирование инерционного звена<br />
      {"\\[  W(p)= \\frac{k}{Tp+1} \\]"}<br />
      Подготовим звено к моделированию с помощью метода разложения на уравнения первого порядка. <br />
      Перейдем от передаточной функцию к соответствующему дифференциальному уравнению:<br />
      {"\\[  W(p) = \\frac{k}{Tp+1}=\\frac{y}{g}; p=\\frac{d}{dt} \\]"}<br />
      {"\\[  (Tp+1)y=kg \\]"}<br />
      {"\\[ T\\frac{dy}{dt}+y=kg  \\]"}<br />
      Перед дальнейшими вычислениями необходимо привести старший коэффициент к единице.Для этого делим все уравнение на T.<br />
      {"\\[  \\frac{dy}{dt} +\\frac{y}{T}=g\\frac{k}{T} \\]"}<br />
      Запишем коэффициенты:<br />
      {"\\[  n=1; \\alpha_1=1; \\alpha_0=\\frac{1}{T};  \\qquad m=0;b_1=0;b_0=\\frac{k}{T} \\]"}<br />
      Так как n=1, то в соответствии с методом разложения на уравнения первого порядка получим:<br />
      {"\\[  y=y_1+\\alpha_ng=y_1+\\alpha_1g \\]"}<br />
      {"\\[  \\frac{dy_1}{dt}=-\\alpha_0y_1+\\alpha_0g=-y_1\\frac{1}{T}+\\alpha_0g \\]"}<br />
      Найдем коэффициенты α0, α1<br />
      {"\\[  b_n = \\alpha_n; b_1 = \\alpha_1; \\alpha_1 = 0 \\]"}<br />
      {"\\[ b_0=\\alpha_0+\\alpha_n\\alpha_{n-1}=\\alpha_0+\\alpha_1\\alpha_0=\\alpha_0+0*1  \\]"}, {"\\[  \\alpha_0=b_0=\\frac{k}{T} \\]"}<br />
      Подставим полученные коэффициенты и запишем готовую систему линейных дифференциальных уравнений:<br />
      {"\\[ \\begin{cases}   y=y_1 \\\\ \\frac{dy_1}{dt} = -y_1 \\frac{1}{T} + g \\frac{k}{T} \\end{cases} \\]"}<br />
      Применив метод Рунге-Кутта к полученной системе уравнений получим:
      {"\\[  y=y_1  \\]"}<br />
      {"\\[  k_1 = (\\frac{k}{T}g - \\frac{y}{T})dt \\]"}<br />
      {"\\[  k_2 = (\\frac{k}{T}g - \\frac{1}{T} (y + \\frac{k_1}{2}) )dt \\]"}<br />
      {"\\[ k_3 = (\\frac{k}{T}g - \\frac{1}{T} (y + \\frac{k_2}{2}) )dt  \\]"}<br />
      {"\\[  k_4 = (\\frac{k}{T}g - \\frac{1}{T} (y + k_3) )dt \\]"}<br />
      {"\\[  y_1 = y_1+(k_1+2k_2+2k_3+k_4)\\frac{1}{6} \\]"}
      </p>


      </div>
    </div>
  );
}

export default Subject1;
