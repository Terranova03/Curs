import React from 'react';
import MathJaxComponent from '../MathJaxComponent.jsx';
import MultiColumnSentences from '../MultiColumnSentences.jsx';
import '../ContentPage.css';

import logo from '../Images/logo.png';
import I from '../Images/1_9.png';
import I1 from '../Images/1_6_1.png';
import I2 from '../Images/1_6_2.png';
import I3 from '../Images/1_6_3.png';
import J from '../Images/1_10.png';
import J1 from '../Images/1_7_1.png';
import J2 from '../Images/1_7_2.png';
import J3 from '../Images/1_7_3.png';
import K from '../Images/1_11.png';


const Subject1 = () => {
  const mathExpression1 = '\\[  \\frac{dy}{dt}=kg \\]'
  const mathExpression2 = '\\(W(p) = {Y(p) \\over G(p)} = k\\)'

  return (
    <div className="content-container">
      <header>
        <div className='headers'>
            <img src={logo} alt="Logo" className="logo" />
            <div className="header-text">
                <h1>ТЕОРИЯ АВТОМАТИЧЕСКОГО УПРАВЛЕНИЯ</h1>
                <p>САЙТ-ПОМОЩНИК ДЛЯ СТУДЕНТОВ</p>
            </div>
        </div>
      </header>
      <div className="content">
        
      <h2>
        Интегрирующие звенья
      </h2>

      <p>К интегрирующим звеньям относятся:</p>

      <ul>
          <li>Идеальное интегрирующее звено,</li>
          <li>Интегрирующее с замедлением,</li>
          <li>Изодромное.</li>
      </ul>

      <p>Идеальным интегрирующим называется звено, которое описывается дифференциальным<br/>
      уравнением <MathJaxComponent mathExpression={mathExpression1} />
      Его передаточная функция имеет вид {"\\[   W(p)= \\frac{Y(p)}{G(p)}=\\frac{k}{p} \\]"}
      </p>

      <h3>
        Пример идеального интегрирующего звена
      </h3>

      <p>
      Гидравлический демпфер состоит из поршня и цилиндра, заполненного вязкой жидкостью. 
      При перемещении поршня рабочая жидкость протекает через небольшие отверстия (они делаются, в частности, в поршне),
      а воздух, который находится в верхней части цилиндра, немного сжимается.<br/>
      Таким образом, создаются силы гидравлического сопротивления и сопротивления сжимающегося и разжимающегося воздуха или газа.
      Получается, что за счет этих сопротивлений и происходит плавное, размеренное движение поршня, 
      что в результате приводит к гасящему толчки эффекту.<br/>
      Итак, гидравлический демпфер можно описать передаточной функцией идеального интегрирующего звена, 
      если в качестве входной величины рассматривать силу F, действующую на поршень, а в качестве выходной-перемещение поршня. 
      Так как скорость движения поршня пропорциональна приложенной силе (без учета инерционных сил)<br/>
      {"\\[ v=\\frac{dy}{dt}=\\frac{F}{S}  \\]"}<br/>
      где S - коэффициент скоростного сопротивления; его перемещение будет пропорционально интегралу от приложенной силы:<br/>
      {"\\[  y= \\int vdt = \\frac{1}{S} \\int Fdt \\]"}
      </p>

      <p className='center-img'>
          <img src={I} alt="I"></img>
      </p>

      <p>
      Переходная характеристика звена имеет вид линейно возрастающей функции<br/>
      {"\\[ h(t) = k \\int_0^t 1 (\\tau) d\\tau = kt1(t)  \\]"}<br/>
      а импульсная переходная функция – ступенчатой функции<br/>
      {"\\[  w(t)=k \\int_0^t \\delta (\\tau) d\\tau = k1(t) \\]"}<br/>
      Выражение для АФЧХ получим, заменив в передаточной функции p на jω:<br/>
      {"\\[   W(j \\omega)= \\frac{k}{j \\omega} = -j \\frac{k}{\\omega}  \\]"}<br/>
      Вещественная частотная характеристика отсутствует, Re(ω)=0. Мнимая частотная характеристика имеет вид<br/>
      {"\\[  Im(\\omega) = -\\frac{k}{\\omega} \\]"}<br/>
      а амплитудная частотная характеристика<br/>
      {"\\[  A(\\omega) = \\frac{k}{\\omega} \\]"}<br/>
      При этом фазовая частотная характеристика следующая:<br/>
      {"\\[  \\varphi (\\omega)=arctg \\frac{Im(\\omega)}{Re(\\omega)} \\pm \\begin{cases} 0 \\text{ при } Re(\\omega) \\geq 0 \\\\ \\pi \\text{ при } Re(\\omega) < 0 \\end{cases} = \\frac{- \\pi}{2}  \\]"}<br/>
      т.е. звено имеет постоянный фазовый сдвиг, который не зависит от частоты.<br/>
      АФЧХ интегрирующего звена имеет вид прямой, совпадающей с отрицательной мнимой полуосью комплексной плоскости.<br/>
      </p>

      <h3>
      Интегрирующее звено с замедлением
      </h3>

      <p>
      Интегрирующее звено с замедлением определяется следующими формулами.<br/>
      {"\\[  T \\frac{d^2y}{dt^2}+ \\frac{dy}{dt} = kg \\]"}<br/>
      {"\\[  W(p) = \\frac{Y(p)}{G(p)}=\\frac{k}{p(1+Tp)} \\]"}<br/>
      </p>

      <p>
        <ul>
          <li>передаточная функция звена:<br/>
          {"\\(W(p) = \\frac{Y(p)}{G(p)} = \\frac{k}{T_{2}^{2}p^{2} + T_{1}p + 1}\\)"}<br />
          {"\\(T_{3,4} = \\frac{T_{1}}{T_{2}} \\pm \\sqrt{\\frac{T_{1}^{2}}{4} - T_{2}^{2}} \\in R\\)"}
          
          </li>
          <li>
          <table>
          <tr>
            <td>
            переходной функции <br/>
            {"\\[  h(t)=k(t-T(1-e^{- \\frac{1}{T}}))1(t) \\]"}
            <p className='center-img'>
            <img src={I1} alt="I1"></img>
            </p>
            </td>
            <td>
            весовой функции <br/>
            {"\\[  w(t) = k(1-e^{- \\frac{1}{T}})1(t) \\]"}
            <p className='center-img'>
            <img src={I2} alt="I2"></img>	
            </p>
            </td>
            <td>
            частотной передаточной функции <br/>
            {"\\[ W(j \\omega)= \\frac{k}{j \\omega (1+j \\omega T)}  \\]"}
          <p className='center-img'>
            <img src={I3} alt="I3"></img>
          </p>
            </td>
          </tr>
        </table>
          </li>
        </ul>
      </p>

      <h3>
      Пример интегрирующего звена с замедлением
      </h3>

      <p>Гидравлическое исполнительное устройство</p>

      <MultiColumnSentences>
            <div>
            <p className='center-img'>
          <img src={J} alt="J"></img>
            </p>
            </div>
            <div>
              <p>
              {"\\[  \\frac{Y(s)}{X(s)} = \\frac{K}{s(Ms+B)} \\]"}<br />
              {"\\[  K=\\frac{Ak_x}{k_p} \\qquad B=(b+ \\frac{A^2}{k_p}) \\]"}<br />
              {"\\[  k_x= \\frac{\\partial g}{\\partial x} \\bigg|_{x_0}  \\qquad  k_p= \\frac{\\partial g}{\\partial P} \\bigg|_{P_0}  \\]"}<br />
              {"\\[  g = g(x,P)\\]"} = поток<br />
              A - площадь поршня
              </p>
            </div>
      </MultiColumnSentences>

      <h3>
        Изодромное звено
      </h3>

      <p>Изодромное звено задается следующими формулами<br />
        {"\\[ \\frac{dy}{dt} = kg +kT \\frac{dg}{dt}  \\]"}<br />
        {"\\[  W(p)= \\frac{Y(p)}{G(p)}=\\frac{k(1+Tp)}{p}  \\]"}<br />
      </p>

      <table>
          <tr>
            <td>
            переходной функции <br/>
            {"\\[  h(t)=(kt+kT)1(t) \\]"}
            <p className='center-img'>
            <img src={J1} alt="J1"></img>
            </p>
            </td>
            <td>
            весовой функции <br/>
            {"\\[  w(t)=k1(t)+kT \\delta (t) \\]"}
            <p className='center-img'>
            <img src={J2} alt="J2"></img>	
            </p>
            </td>
            <td>
            частотной передаточной функции <br/>
            {"\\[ W(j \\omega)=\\frac{k(1+j \\omega T)}{j \\omega}  \\]"}
          <p className='center-img'>
            <img src={J3} alt="J3"></img>
          </p>
            </td>
          </tr>
        </table>

      <p>
        <strong>Примером</strong> изодромного звена может послужить пружина с демпфером<br />
        Входная величина – прикладываемая сила F, выходная величина x – перемещение  точки a, в которой приложена сила. <br />
        Результирующее перемещение точки определяется дифференциальным уравнением<br />
         {"\\[  x = \\frac{F}{c}+\\frac{1}{s} \\int F dt \\]"}<br />
        из которого и получается рассматриваемая передаточная функция.<br />
        Здесь c – жесткость пружины, s –коэффициент скоростного сопротивления демпфера.
      </p>

      <p className='center-img'>
          <img src={K} alt="K"></img>
      </p>

      </div>
    </div>
  );
}

export default Subject1;
