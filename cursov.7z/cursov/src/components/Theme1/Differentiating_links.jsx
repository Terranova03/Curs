import React from 'react';
import MathJaxComponent from '../MathJaxComponent.jsx';
import '../ContentPage.css';

import logo from '../Images/logo.png';
import L from '../Images/1_12.png';
import M1 from '../Images/1_8_1.png';
import M2 from '../Images/1_8_2.png';
import M3 from '../Images/1_8_3.png';
import M from '../Images/1_13.png';


const Subject1 = () => {
  const mathExpression1 = '\\[  y=k \\frac{dg}{dt} \\]'

  return (
    <div className="content-container">
      <header>
        <div className='headers'>
            <img src={logo} alt="Logo" className="logo" />
            <div className="header-text">
                <h1>ТЕОРИЯ АВТОМАТИЧЕСКОГО УПРАВЛЕНИЯ</h1>
                <p>САЙТ-ПОМОЩНИК ДЛЯ СТУДЕНТОВ</p>
            </div>
        </div>
      </header>
      <div className="content">
        
      <h2>
        Дифференцирующие звенья
      </h2>

      <p>К дифференцирующим звеньям относятся:</p>

      <ul>
          <li>идеальное дифференцирующее звено,</li>
          <li>дифференцирующее звено с замедлением.</li>
      </ul>

      <h3>
        Идеальное дифференцирующее звено
      </h3>

      <p>Идеальным дифференцирующим называется звено, которое описывается дифференциальным уравнением<br />
      <MathJaxComponent mathExpression={mathExpression1} /><br />
      Его передаточная функция имеет вид<br />
      {"\\[   W(p)=\\frac{Y(p)}{G(p)} = kp \\]"}
      </p>

      <h3>
        Пример идеального дифференцирующего звена 
      </h3>

      <p>
        Тахогенератор постоянного тока. В качестве входной величины рассмотрим угол поворота его ротора, 
        а в качестве выходной-напряжение якоря.<br />
        {"\\[  U = k \\frac{d \\alpha}{dt}  \\]"}<br />
        где k - коэффициент преобразования числа оборотов {"\\[ n(t) = \\frac{d \\alpha}{dt}  \\]"} в напряжение.<br />
        Переходная характеристика дифференцирующего звена определяется выражением<br />
        {"\\[ h(t)=k \\delta(t)  \\]"}<br />
        и имеет вид δ-функций<br />
        <p className='center-img'>
          <img src={L} alt="L"></img>
        </p><br />
        Импульсная переходная функция идеального дифференцирующего звена представляет собой "дуплет" δ-функций {"\\[ w(t)=k \\delta \\dot{(t)}  \\]"}<br />
        Рассмотрим теперь частотные характеристики звена. Амплитудно-фазовая характеристика<br />
        {"\\[ W(j \\omega)= jk \\omega  \\]"}<br />
        совпадает с положительной мнимой полуосью комплексной плоскости; вещественная частотная характеристика равна 0, Re(ω)=0; 
        мнимая частотная характеристика соответствует выражению<br />
        {"\\[ Im(\\omega)=k \\omega  \\]"}<br />
        т.е. представляет собой линейно нарастающую функцию. С ней совпадает амплитудная частотная характеристика, которая имеет вид<br />
        {"\\[  A(\\omega)=\\sqrt{(Re(\\omega))^2+(Im(\\omega))^2} = Im(\\omega)=k \\omega \\]"}<br />
        Выражение для ФЧХ следующее:<br />
        {"\\[  \\varphi (\\omega)=arctg \\frac{Im(\\omega)}{Re(\\omega)} \\pm \\begin{cases} 0 \\text{ при } Re(\\omega) \\geq 0 \\\\ \\pi \\text{ при } Re(\\omega) < 0 \\end{cases} = \\frac{\\pi}{2} \\]"}<br />
        Следовательно, на всех частотах имеется постоянный фазовый сдвиг.
      </p>

      <h3>
      Дифференцирующее звено с замедлением
      </h3>

      <p>
      Дифференцирующее звено с замедлением описывается дифференциальным уравнением вида<br />
      {"\\[ T\\frac{dy}{dt}+y=k\\frac{dg}{dt}  \\]"}<br />
      Передаточная функция:  {"\\[  W(p)=\\frac{Y(p)}{G(p)} = \\frac{kp}{Tp+1} \\]"}<br />
      Ниже представлены  функции и графики.
      </p>

      <table>
          <tr>
            <td>
            переходной функции <br/>
            {"\\[  h(t)=\\frac{k}{T}e^{-\\frac{t}{T}}\\delta (t) \\]"}
            <p className='center-img'>
            <img src={M1} alt="M1"></img>
            </p>
            </td>
            <td>
            весовой функции <br/>
            {"\\[  w(t)=\\frac{k}{T}\\delta (t) - \\frac{k}{T^2}e^{-\\frac{t}{T}} 1(t) \\]"}
            <p className='center-img'>
            <img src={M2} alt="M2"></img>	
            </p>
            </td>
            <td>
            частотной передаточной функции <br/>
            {"\\[  W(j \\omega ) =\\frac{j \\omega k}{j \\omega T+1} \\]"}
          <p className='center-img'>
            <img src={M3} alt="M3"></img>
          </p>
            </td>
          </tr>
        </table>

      <h3>
      Пример дифференцирующего звена с замедлением
      </h3>

      <p>
      Дифференцирующий конденсатор<br />
      <p className='center-img'>
          <img src={M} alt="M"></img>
      </p><br />
      u1 - выходное напряжение схемы;<br />
      u2 - входное напряжение<br />
      Ток в рассматриваемой цепи определяется уравнением<br />
      {"\\[  Ri+\\frac{1}{C} \\int idt = u_1 \\]"}<br />
      из которого следует выражение<br />
      {"\\[  U_2(p)=\\frac{Tp}{1+Tp}U_1(p) \\]"}<br />
      где T=RC постоянная времени цепи, U1, U2 - изображения входной и выходной величин
      </p>

      
      </div>
    </div>
  );
}

export default Subject1;
