import './App.css';
import { Routes, Route } from 'react-router-dom';


import Menu from './components/Menu';
import Positional_links from './components/Theme1/Positional_links';
import Integrating_links from './components/Theme1/Integrating_links';
import Differentiating_links from './components/Theme1/Differentiating_links';
import Links_Modeling from './components/Theme1/Links_Modeling';
import Feedback from './components/Theme2/Feedback';
import Feedback_Modeling from './components/Theme2/Feedback_Modeling';
import Stability_Research_Methods from './components/Theme3/Stability_Research_Methods';
import Routh_Hurwitz from './components/Theme3/Routh_Hurwitz';
import Mikhailov_and_Nyquist from './components/Theme3/Mikhailov_and_Nyquist';
import Assessing_quality_of_regulation from './components/Theme4/Assessing_quality_of_regulation';
import Direct_integral from './components/Theme4/Direct_integral';
import Stability_study from './components/Theme5/Stability_study';
import Mathematical_description_and_modeling_of_delay from './components/Theme5/Mathematical_description_and_modeling_of_delay';


function App() {
  return (
    <>
      <Menu/>
      <div className='Background'>
      <Routes>
        <Route path="/" element={<Positional_links />} />
        <Route path="/Positional_links" element={<Positional_links />} />
        <Route path="/Integrating_links" element={<Integrating_links />} />
        <Route path="/Differentiating_links" element={<Differentiating_links />} />
        <Route path="/Links_Modeling" element={<Links_Modeling />} />
        <Route path="/Feedback" element={<Feedback />} />
        <Route path="/Feedback_Modeling" element={<Feedback_Modeling />} />
        <Route path="/Stability_Research_Methods" element={<Stability_Research_Methods />} />
        <Route path="/Routh_Hurwitz" element={<Routh_Hurwitz />} />
        <Route path="/Mikhailov_and_Nyquist" element={<Mikhailov_and_Nyquist />} />
        <Route path="/Assessing_quality_of_regulation" element={<Assessing_quality_of_regulation />} />
        <Route path="/Direct_integral" element={<Direct_integral />} />
        <Route path="Mathematical_description_and_modeling_of_delay" element={<Mathematical_description_and_modeling_of_delay />} />
        <Route path="/Stability_study" element={<Stability_study />} />
      </Routes>
      </div>
    </>
  );
}

export default App;
